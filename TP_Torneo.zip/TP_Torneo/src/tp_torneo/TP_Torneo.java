/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp_torneo;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Criteria;
import java.util.List;
import org.hibernate.HibernateException;

/**
 *
 * @author angel
 */
public class TP_Torneo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*ALTA*/
        Session s = connection.Controller.getSessionFactory().openSession();
        Transaction tr = s.beginTransaction();
        pojos.Equipo e = new pojos.Equipo();
        e.setNombre("San Lorenzo");
        e.setTitulares(11);
        e.setSuplentes(5);
        e.setDirectorTecnico("Rubén Darío Insúa Carballo");
        e.setPuntos(0);
        e.setPartidosJugados(1);
        e.setGolesUltimaFecha(0);
        s.save(e);
        tr.commit();
        s.close();
        tr = null;
        System.out.println("Grabado exitoso");
        
        /*MODIFICACION*/
        Session se = connection.Controller.getSessionFactory().openSession();        
        Transaction tx = s.beginTransaction();   
        pojos.Equipo stu = (pojos.Equipo) se.load(pojos.Equipo.class, 3);
        stu.setPuntos(2);    
        s.update(stu);       
        tx.commit();
        se.close();
        tx = null;
        System.out.println("Actualización exitosa");
        
        /*CONSULTA*/     
        Session sec = connection.Controller.getSessionFactory().openSession();
        Criteria c = s.createCriteria(pojos.Equipo.class);
        List<pojos.Equipo> equi = c.list();
        for(pojos.Equipo es : equi)
        System.out.println("ID Equipo: " + e.getIdEquipo() + "Nombre: " + e.getNombre() + "Titulares: " + e.getTitulares() + "Suplentes: " + e.getSuplentes() + "Director Tecnico: " + e.getDirectorTecnico() + "Puntos: " + e.getPuntos() + "Partidos Jugados: " + e.getPartidosJugados() + "Goles Ultima Fecha: " + e.getGolesUltimaFecha() );
        System.out.println("Listado Completo");
        
        /*CONSULTA*/
        Session session = connection.Controller.getSessionFactory().openSession();
      Transaction t = null;      
      try {
         t = session.beginTransaction();
         pojos.Equipo equipo = (pojos.Equipo)session.get(pojos.Equipo.class, 6); 
         session.delete(equipo); 
         tx.commit();
      } catch (HibernateException ex) {
         if (t!=null) t.rollback();
         ex.printStackTrace(); 
      } finally {
         session.close(); 
      }

    }
    
}
